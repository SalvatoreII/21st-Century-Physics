import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from cube_32k import (
    create_screen_lookup_table, 
    get_screen_bounds,
    ramp_to_gray,
    gray_to_coordinates
)
from seq_opt import sequency_decompose, print_spectrum_summary

def create_image_from_data(data: np.ndarray, lookup: np.ndarray, 
                          colormap: str = 'viridis') -> tuple:
    """
    Create 2D image array from 32K data using screen lookup table.
    
    Args:
        data: Array of 32768 values to visualize
        lookup: Screen position lookup table (32768, 2)
        colormap: Matplotlib colormap name
    
    Returns:
        (image_array, extent) where extent is (min_h, max_h, min_v, max_v)
    """
    # Get screen bounds
    min_h, max_h, min_v, max_v = get_screen_bounds(lookup)
    
    # Create image array (inverted y-axis for display)
    width = max_h - min_h + 1
    height = max_v - min_v + 1
    image = np.full((height, width), np.nan)
    
    # Normalize data to [0, 1] for colormapping
    data_min, data_max = np.min(data), np.max(data)
    if data_max > data_min:
        data_norm = (data - data_min) / (data_max - data_min)
    else:
        data_norm = np.zeros_like(data)
    
    # Fill image array
    for step in range(32768):
        h, v = lookup[step]
        # Convert to array indices
        col = h - min_h
        row = v - min_v
        image[row, col] = data_norm[step]
    
    extent = (min_h, max_h, min_v, max_v)
    return image, extent

def visualize_32k_ramp(save_path: str = None, show_plot: bool = True):
    """
    Visualize the 32K unit ramp in the Hamiltonian path through the cube.
    
    Args:
        save_path: If provided, save image to this path
        show_plot: If True, display the plot
    """
    print("=" * 70)
    print("32K Unit Ramp Visualization")
    print("=" * 70)
    
    # Create unit ramp
    print("\nCreating 32K unit ramp...")
    ramp = np.arange(32768, dtype=float)
    
    # Create lookup table (Hamiltonian origin - frontmost corner)
    print("Creating screen lookup table...")
    lookup = create_screen_lookup_table(hamiltonian_origin=True)
    
    # Create image
    print("Rendering image...")
    image, extent = create_image_from_data(ramp, lookup, colormap='viridis')
    
    # Create figure
    fig, ax = plt.subplots(figsize=(12, 12), dpi=100)
    
    # Display image
    im = ax.imshow(image, extent=extent, origin='lower', 
                   cmap='viridis', interpolation='nearest')
    
    # Add colorbar
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label('Normalized Ramp Value', fontsize=12)
    
    # Labels and title
    ax.set_xlabel('Horizontal Screen Coordinate', fontsize=12)
    ax.set_ylabel('Vertical Screen Coordinate', fontsize=12)
    ax.set_title('32K Unit Ramp - Hamiltonian Path Through Cube\n' + 
                 '(All 32,768 points visible)', fontsize=14, fontweight='bold')
    
    # Add grid
    ax.grid(True, alpha=0.3, linewidth=0.5)
    
    # Add info text
    info_text = f'Grid: 32×32×32\nPoints: 32,768\nPath: Hamiltonian (Gray code bit-interleaved)'
    ax.text(0.02, 0.98, info_text, transform=ax.transAxes,
            fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    
    if save_path:
        print(f"Saving image to {save_path}...")
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print("Image saved.")
    
    if show_plot:
        print("Displaying plot...")
        plt.show()
    else:
        plt.close()
    
    return fig, ax

def analyze_and_visualize_ramp(save_spectrum_path: str = None):
    """
    Perform sequency decomposition on 32K ramp and analyze results.
    
    Args:
        save_spectrum_path: If provided, save spectrum visualization
    """
    print("\n" + "=" * 70)
    print("Sequency Analysis of 32K Unit Ramp")
    print("=" * 70)
    
    # Create unit ramp
    ramp = np.arange(32768, dtype=float)
    
    # Perform sequency decomposition
    print("\nPerforming sequency decomposition on 32,768 samples...")
    import time
    start = time.time()
    spectrum = sequency_decompose(ramp.copy())
    elapsed = time.time() - start
    print(f"Decomposition completed in {elapsed:.4f} seconds")
    
    # Analyze spectrum
    print("\n" + "-" * 70)
    print_spectrum_summary(spectrum, threshold=1e-6, max_display=20)
    print("-" * 70)
    
    # Count non-zero components
    threshold = 1e-6
    non_zero = np.sum(np.abs(spectrum) > threshold)
    print(f"\nNon-zero components (threshold {threshold}): {non_zero} / 32,768")
    print(f"Compression ratio: {32768 / non_zero:.1f}x")
    
    # For unit ramp, we expect only sequencies of form 2^n - 1
    # (W0, W1, W3, W7, W15, W31, W63, W127, W255, W511, W1023, W2047, W4095, W8191, W16383, W32767)
    expected_sequencies = [2**n - 1 for n in range(16)]
    expected_sequencies[0] = 0  # W0 is the DC component
    
    print("\nExpected non-zero sequencies for unit ramp:")
    print("W" + ", W".join(str(s) for s in expected_sequencies))
    
    # Verify
    print("\nActual non-zero sequencies:")
    actual = [i for i in range(len(spectrum)) if abs(spectrum[i]) > threshold]
    print("W" + ", W".join(str(s) for s in actual[:20]))
    if len(actual) > 20:
        print(f"... and {len(actual) - 20} more")
    
    # Visualize spectrum magnitude
    if save_spectrum_path:
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10))
        
        # Linear scale
        indices = np.arange(len(spectrum))
        magnitudes = np.abs(spectrum)
        
        ax1.stem(indices[:100], magnitudes[:100], linefmt='b-', 
                markerfmt='bo', basefmt='k-', label='Spectrum magnitude')
        ax1.set_xlabel('Sequency Index')
        ax1.set_ylabel('|Amplitude|')
        ax1.set_title('Sequency Spectrum - First 100 Components (Linear Scale)')
        ax1.grid(True, alpha=0.3)
        ax1.legend()
        
        # Log scale - all components
        non_zero_mask = magnitudes > threshold
        ax2.semilogy(indices[non_zero_mask], magnitudes[non_zero_mask], 
                    'ro', markersize=4, label='Non-zero components')
        ax2.set_xlabel('Sequency Index')
        ax2.set_ylabel('|Amplitude| (log scale)')
        ax2.set_title(f'All Non-Zero Spectrum Components (n={non_zero})')
        ax2.grid(True, alpha=0.3, which='both')
        ax2.legend()
        
        plt.tight_layout()
        plt.savefig(save_spectrum_path, dpi=150, bbox_inches='tight')
        print(f"\nSpectrum plot saved to {save_spectrum_path}")
        plt.close()
    
    return spectrum

def create_polynomial_visualization(degree: int = 2, save_path: str = None):
    """
    Visualize higher-order polynomial in the cube.
    
    Args:
        degree: Polynomial degree (1=linear/ramp, 2=quadratic, 3=cubic, etc.)
        save_path: If provided, save image to this path
    """
    print(f"\n{'=' * 70}")
    print(f"Polynomial Degree {degree} Visualization")
    print("=" * 70)
    
    # Create polynomial
    t = np.arange(32768, dtype=float) / 32767  # Normalize to [0, 1]
    data = t ** degree
    
    # Create lookup table
    lookup = create_screen_lookup_table(hamiltonian_origin=True)
    
    # Create image
    image, extent = create_image_from_data(data, lookup, colormap='plasma')
    
    # Create figure
    fig, ax = plt.subplots(figsize=(12, 12), dpi=100)
    
    # Display
    im = ax.imshow(image, extent=extent, origin='lower', 
                   cmap='plasma', interpolation='nearest')
    
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label(f't^{degree} (normalized)', fontsize=12)
    
    ax.set_xlabel('Horizontal Screen Coordinate', fontsize=12)
    ax.set_ylabel('Vertical Screen Coordinate', fontsize=12)
    ax.set_title(f'Polynomial t^{degree} in 32K Cube\n' + 
                 'Hamiltonian Path Visualization', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, linewidth=0.5)
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Saved to {save_path}")
        plt.close()
    else:
        plt.show()
    
    return fig, ax

# Main execution
if __name__ == "__main__":
    # Visualize the unit ramp
    print("\n" + "=" * 70)
    print("PART 1: Unit Ramp Visualization")
    print("=" * 70)
    visualize_32k_ramp(save_path='/mnt/user-data/outputs/32k_unit_ramp.png', 
                       show_plot=False)
    
    # Analyze with sequency decomposition
    print("\n" + "=" * 70)
    print("PART 2: Sequency Decomposition Analysis")
    print("=" * 70)
    spectrum = analyze_and_visualize_ramp(
        save_spectrum_path='/mnt/user-data/outputs/32k_ramp_spectrum.png')
    
    # Create some polynomial visualizations
    print("\n" + "=" * 70)
    print("PART 3: Polynomial Visualizations")
    print("=" * 70)
    for degree in [2, 3]:
        create_polynomial_visualization(
            degree=degree, 
            save_path=f'/mnt/user-data/outputs/32k_polynomial_degree_{degree}.png')
    
    print("\n" + "=" * 70)
    print("All visualizations complete!")
    print("=" * 70)
    print("\nOutput files:")
    print("  - 32k_unit_ramp.png")
    print("  - 32k_ramp_spectrum.png")
    print("  - 32k_polynomial_degree_2.png")
    print("  - 32k_polynomial_degree_3.png")
