import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
from matplotlib.colors import TwoSlopeNorm
from cube_32k import create_screen_lookup_table, get_screen_bounds
from seq_opt import sequency_reconstruct
import time

def generate_sequency_basis_function(sequency_index: int, n: int = 32768) -> np.ndarray:
    """
    Generate a single Walsh/sequency basis function by inverse transform.
    
    Create unit impulse in sequency domain and transform to spatial domain.
    Since sequency transform is auto-inverse, this is the same operation.
    
    Args:
        sequency_index: Which sequency to generate (0 to n-1)
        n: Number of samples
    
    Returns:
        Spatial pattern for that sequency
    """
    # Create unit impulse in sequency domain
    spectrum = np.zeros(n)
    spectrum[sequency_index] = 1.0
    
    # Transform to spatial domain (auto-inverse property)
    spatial = sequency_reconstruct(spectrum.copy())
    
    return spatial

def visualize_single_sequency(sequency_index: int, save_path: str = None):
    """
    Visualize a single sequency basis function in the 32K cube.
    
    Args:
        sequency_index: Which sequency to visualize
        save_path: If provided, save image
    """
    print(f"\nGenerating sequency basis function W{sequency_index}...")
    
    # Generate basis function
    basis = generate_sequency_basis_function(sequency_index)
    
    # Get screen lookup
    lookup = create_screen_lookup_table(hamiltonian_origin=True)
    min_h, max_h, min_v, max_v = get_screen_bounds(lookup)
    
    # Create image
    width = max_h - min_h + 1
    height = max_v - min_v + 1
    image = np.full((height, width), np.nan)
    
    # Normalize to [-1, 1] for diverging colormap
    data_max = np.max(np.abs(basis))
    if data_max > 0:
        basis_norm = basis / data_max
    else:
        basis_norm = basis
    
    # Fill image
    for step in range(32768):
        h, v = lookup[step]
        col = h - min_h
        row = v - min_v
        image[row, col] = basis_norm[step]
    
    # Create figure
    fig, ax = plt.subplots(figsize=(12, 12), dpi=100)
    
    # Use diverging colormap centered at zero
    im = ax.imshow(image, extent=(min_h, max_h, min_v, max_v), 
                   origin='lower', cmap='RdBu_r', 
                   norm=TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1),
                   interpolation='nearest')
    
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label('Normalized Amplitude', fontsize=12)
    
    # Count zero crossings in linear order
    zero_crossings = np.sum(np.diff(np.sign(basis)) != 0)
    
    ax.set_xlabel('Horizontal Screen Coordinate', fontsize=12)
    ax.set_ylabel('Vertical Screen Coordinate', fontsize=12)
    ax.set_title(f'Sequency Basis Function W{sequency_index}\n' + 
                 f'Zero Crossings: {zero_crossings}', 
                 fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, linewidth=0.5)
    
    info_text = f'Sequency: W{sequency_index}\nZero crossings: {zero_crossings}\nPattern: Walsh function'
    ax.text(0.02, 0.98, info_text, transform=ax.transAxes,
            fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Saved to {save_path}")
        plt.close()
    else:
        plt.show()
    
    return basis

def create_hamiltonian_path_animation(sequency_index: int, 
                                     save_path: str = None,
                                     duration_seconds: float = 60.0,
                                     fps: int = 30):
    """
    Create animation showing a sequency function flowing through Hamiltonian path.
    
    Args:
        sequency_index: Which sequency to animate
        save_path: Path to save animation (should end in .mp4 or .gif)
        duration_seconds: Total duration of animation
        fps: Frames per second
    """
    print(f"\n{'=' * 70}")
    print(f"Creating Hamiltonian Path Animation for W{sequency_index}")
    print("=" * 70)
    
    # Generate basis function
    print("Generating basis function...")
    basis = generate_sequency_basis_function(sequency_index)
    
    # Get screen lookup
    lookup = create_screen_lookup_table(hamiltonian_origin=True)
    min_h, max_h, min_v, max_v = get_screen_bounds(lookup)
    
    # Calculate animation parameters
    total_frames = int(duration_seconds * fps)
    points_per_frame = 32768 / total_frames
    
    print(f"Animation parameters:")
    print(f"  Duration: {duration_seconds} seconds")
    print(f"  FPS: {fps}")
    print(f"  Total frames: {total_frames}")
    print(f"  Points per frame: {points_per_frame:.1f}")
    
    # Create figure
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 7))
    
    # Left plot: 2D cube view
    width = max_h - min_h + 1
    height = max_v - min_v + 1
    image = np.full((height, width), np.nan)
    
    im1 = ax1.imshow(image, extent=(min_h, max_h, min_v, max_v),
                     origin='lower', cmap='RdBu_r',
                     norm=TwoSlopeNorm(vmin=-1, vcenter=0, vmax=1),
                     interpolation='nearest')
    
    ax1.set_xlabel('Horizontal', fontsize=10)
    ax1.set_ylabel('Vertical', fontsize=10)
    ax1.set_title(f'W{sequency_index} in 32K Cube', fontsize=12, fontweight='bold')
    ax1.grid(True, alpha=0.3, linewidth=0.5)
    
    # Right plot: 1D path view
    steps = np.arange(32768)
    line, = ax2.plot([], [], 'b-', linewidth=0.5, alpha=0.7)
    point, = ax2.plot([], [], 'ro', markersize=8)
    
    ax2.set_xlabel('Hamiltonian Path Step', fontsize=10)
    ax2.set_ylabel('Amplitude', fontsize=10)
    ax2.set_title('Value Along Path', fontsize=12, fontweight='bold')
    ax2.set_xlim(0, 32768)
    ax2.set_ylim(-1.1, 1.1)
    ax2.grid(True, alpha=0.3)
    ax2.axhline(y=0, color='k', linewidth=0.5, alpha=0.5)
    
    # Progress text
    progress_text = ax1.text(0.02, 0.98, '', transform=ax1.transAxes,
                            fontsize=10, verticalalignment='top',
                            bbox=dict(boxstyle='round', facecolor='white', alpha=0.9))
    
    # Normalize basis
    data_max = np.max(np.abs(basis))
    if data_max > 0:
        basis_norm = basis / data_max
    else:
        basis_norm = basis
    
    def init():
        """Initialize animation."""
        line.set_data([], [])
        point.set_data([], [])
        progress_text.set_text('')
        return line, point, im1, progress_text
    
    def animate(frame):
        """Update animation for each frame."""
        # Calculate which step we're at
        current_step = int(frame * points_per_frame)
        if current_step >= 32768:
            current_step = 32767
        
        # Update 2D view - show all points up to current
        image_copy = np.full((height, width), np.nan)
        for step in range(current_step + 1):
            h, v = lookup[step]
            col = h - min_h
            row = v - min_v
            image_copy[row, col] = basis_norm[step]
        
        im1.set_array(image_copy)
        
        # Update 1D view
        line.set_data(steps[:current_step+1], basis_norm[:current_step+1])
        point.set_data([current_step], [basis_norm[current_step]])
        
        # Update progress
        progress = (current_step + 1) / 32768 * 100
        progress_text.set_text(f'Step: {current_step+1:,} / 32,768\n' +
                              f'Progress: {progress:.1f}%\n' +
                              f'Value: {basis_norm[current_step]:+.3f}')
        
        return line, point, im1, progress_text
    
    # Create animation
    print("Rendering animation...")
    anim = animation.FuncAnimation(fig, animate, init_func=init,
                                  frames=total_frames, interval=1000/fps,
                                  blit=True, repeat=True)
    
    if save_path:
        print(f"Saving animation to {save_path}...")
        if save_path.endswith('.gif'):
            anim.save(save_path, writer='pillow', fps=fps)
        elif save_path.endswith('.mp4'):
            anim.save(save_path, writer='ffmpeg', fps=fps, bitrate=1800)
        print(f"Animation saved!")
    else:
        plt.show()
    
    plt.close()
    return anim

def visualize_primary_rademacher_functions(save_dir: str = '/mnt/user-data/outputs'):
    """
    Visualize the primary Rademacher functions (low-order sequencies).
    These are W1, W3, W7, W15, W31, W63, W127, W255, W511, W1023...
    (i.e., 2^n - 1)
    
    Args:
        save_dir: Directory to save images
    """
    print("=" * 70)
    print("Visualizing Primary Rademacher Functions")
    print("=" * 70)
    
    # Primary sequencies: 2^n - 1 for n = 0 to 10
    primary_sequencies = [0, 1, 3, 7, 15, 31, 63, 127, 255, 511, 1023]
    
    for seq_idx in primary_sequencies:
        save_path = f'{save_dir}/sequency_W{seq_idx:04d}.png'
        visualize_single_sequency(seq_idx, save_path=save_path)
    
    print("\n" + "=" * 70)
    print("Primary Rademacher functions complete!")
    print("=" * 70)

if __name__ == "__main__":
    # Visualize primary Rademacher functions
    print("\nPart 1: Static visualizations of primary sequencies")
    visualize_primary_rademacher_functions()
    
    # Create a short animation for demonstration (10 seconds)
    print("\n\nPart 2: Creating animation for W1 (10 second demo)")
    print("Note: Full 60-second animations take significant time to render.")
    print("For quick demo, using 10 seconds at 10 fps")
    
    create_hamiltonian_path_animation(
        sequency_index=1,
        save_path='/mnt/user-data/outputs/hamiltonian_path_W1_demo.gif',
        duration_seconds=10.0,
        fps=10
    )
    
    print("\n" + "=" * 70)
    print("All visualizations complete!")
    print("=" * 70)
