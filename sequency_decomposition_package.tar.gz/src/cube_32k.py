import numpy as np
from typing import Tuple

def ramp_to_gray(n: int) -> int:
    """
    Convert ramp step number to Gray code.
    Gray code is XOR of n with n>>1
    
    Args:
        n: Ramp step number
    
    Returns:
        Gray code value
    """
    return n ^ (n >> 1)

def gray_to_ramp(gray: int) -> int:
    """
    Convert Gray code back to ramp step number.
    Each bit is accumulated XOR of all previous Gray code bits.
    
    Args:
        gray: Gray code value
    
    Returns:
        Ramp step number
    """
    n = gray
    gray >>= 1
    while gray:
        n ^= gray
        gray >>= 1
    return n

def gray_to_coordinates(gray: int) -> Tuple[int, int, int]:
    """
    Convert 15-bit Gray code to (z, x, y) coordinates by bit interleaving.
    
    Gray code bits ABCDEFGHIJKLMNO are dealt out as:
    - z: ADGJM (bits 14, 11, 8, 5, 2)
    - x: BEHKN (bits 13, 10, 7, 4, 1)
    - y: CFILO (bits 12, 9, 6, 3, 0)
    
    Args:
        gray: 15-bit Gray code value
    
    Returns:
        (z, x, y) coordinates, each 5 bits (0-31)
    """
    z = 0
    x = 0
    y = 0
    
    # Extract bits and build coordinates
    # Starting from MSB (bit 14) down to LSB (bit 0)
    for i in range(5):
        # z gets bits 14, 11, 8, 5, 2 (every 3rd starting at 14)
        z |= ((gray >> (14 - 3*i)) & 1) << (4 - i)
        
        # x gets bits 13, 10, 7, 4, 1 (every 3rd starting at 13)
        x |= ((gray >> (13 - 3*i)) & 1) << (4 - i)
        
        # y gets bits 12, 9, 6, 3, 0 (every 3rd starting at 12)
        y |= ((gray >> (12 - 3*i)) & 1) << (4 - i)
    
    return (z, x, y)

def coordinates_to_gray(z: int, x: int, y: int) -> int:
    """
    Convert (z, x, y) coordinates back to 15-bit Gray code.
    Reverse of gray_to_coordinates - interleaves the bits.
    
    Args:
        z, x, y: Coordinates (each 5 bits, 0-31)
    
    Returns:
        15-bit Gray code value
    """
    gray = 0
    
    for i in range(5):
        # Interleave bits: z, x, y, z, x, y, ...
        gray |= ((z >> (4 - i)) & 1) << (14 - 3*i)  # z bits at positions 14,11,8,5,2
        gray |= ((x >> (4 - i)) & 1) << (13 - 3*i)  # x bits at positions 13,10,7,4,1
        gray |= ((y >> (4 - i)) & 1) << (12 - 3*i)  # y bits at positions 12,9,6,3,0
    
    return gray

def coordinates_to_screen(z: int, x: int, y: int, hamiltonian_origin: bool = True) -> Tuple[int, int]:
    """
    Project 3D coordinates to 2D screen position.
    
    Two coordinate system options:
    
    Standard origin (behind plane):
    - z: (6, 2), x: (0, -7), y: (-5, 2)
    - Screen position = z*(6,2) + x*(0,-7) + y*(-5,2)
    
    Hamiltonian path origin (frontmost corner) - NEGATED:
    - z: (-6, -2), x: (0, 7), y: (5, -2)
    - Screen position = z*(-6,-2) + x*(0,7) + y*(5,-2)
    
    The plane defined by unit vectors is at 1/3 of corner diagonal.
    Front corner is +2/3 from plane, back corner is -1/3.
    
    Args:
        z, x, y: Grid coordinates (0-31)
        hamiltonian_origin: If True, use negated vectors (front corner origin)
    
    Returns:
        (horizontal, vertical) screen position
    """
    if hamiltonian_origin:
        # Negated unit vectors - origin at frontmost corner
        horizontal = -6*z + 5*y
        vertical = -2*(z + y) + 7*x
    else:
        # Standard unit vectors - origin behind plane
        horizontal = 6*z - 5*y
        vertical = 2*(z + y) - 7*x
    
    return (horizontal, vertical)

def ramp_to_screen(step: int, hamiltonian_origin: bool = True) -> Tuple[int, int]:
    """
    Convert ramp step number directly to screen position.
    
    Args:
        step: Position in linear ramp (0 to 32767)
        hamiltonian_origin: If True, use frontmost corner as origin
    
    Returns:
        (horizontal, vertical) screen position
    """
    gray = ramp_to_gray(step)
    z, x, y = gray_to_coordinates(gray)
    return coordinates_to_screen(z, x, y, hamiltonian_origin)

def create_screen_lookup_table(hamiltonian_origin: bool = True) -> np.ndarray:
    """
    Pre-compute screen positions for all 32K points.
    Returns array where index is ramp step, value is (h, v) screen position.
    
    Args:
        hamiltonian_origin: If True, use frontmost corner as origin
    
    Returns:
        Array of shape (32768, 2) with screen coordinates
    """
    lookup = np.zeros((32768, 2), dtype=int)
    
    for step in range(32768):
        lookup[step] = ramp_to_screen(step, hamiltonian_origin)
    
    return lookup

def get_screen_bounds(lookup: np.ndarray) -> Tuple[int, int, int, int]:
    """
    Get the bounding box of all screen positions.
    
    Args:
        lookup: Screen position lookup table
    
    Returns:
        (min_h, max_h, min_v, max_v)
    """
    min_h = np.min(lookup[:, 0])
    max_h = np.max(lookup[:, 0])
    min_v = np.min(lookup[:, 1])
    max_v = np.max(lookup[:, 1])
    
    return (min_h, max_h, min_v, max_v)

def permute_coordinates(z: int, x: int, y: int, perm: Tuple[int, int, int]) -> Tuple[int, int, int]:
    """
    Permute coordinates for rotation.
    
    Args:
        z, x, y: Original coordinates
        perm: Permutation tuple - which original coord goes to (z', x', y')
              E.g., (0,1,2) = identity, (1,0,2) = swap z and x
    
    Returns:
        Permuted (z', x', y') coordinates
    """
    coords = [z, x, y]
    return (coords[perm[0]], coords[perm[1]], coords[perm[2]])

# Test and demonstration
if __name__ == "__main__":
    print("=" * 70)
    print("32K Cube - Gray Code Bit Interleaving System")
    print("=" * 70)
    
    # Test basic conversions
    print("\nTest 1: Basic conversions for step 0")
    step = 0
    gray = ramp_to_gray(step)
    z, x, y = gray_to_coordinates(gray)
    h, v = coordinates_to_screen(z, x, y)
    print(f"Step {step} -> Gray {gray:015b} -> ({z},{x},{y}) -> screen ({h},{v})")
    
    # Verify round trip
    gray_back = coordinates_to_gray(z, x, y)
    step_back = gray_to_ramp(gray_back)
    print(f"Round trip: ({z},{x},{y}) -> Gray {gray_back:015b} -> Step {step_back}")
    print(f"Round trip successful: {step == step_back}")
    
    print("\nTest 2: Sample points along the ramp")
    for step in [0, 1, 100, 1000, 10000, 32767]:
        gray = ramp_to_gray(step)
        z, x, y = gray_to_coordinates(gray)
        h, v = coordinates_to_screen(z, x, y)
        print(f"Step {step:5d}: Gray {gray:015b} -> ({z:2d},{x:2d},{y:2d}) -> screen ({h:4d},{v:4d})")
    
    print("\nTest 3: Creating lookup tables for both coordinate systems...")
    lookup_ham = create_screen_lookup_table(hamiltonian_origin=True)
    lookup_std = create_screen_lookup_table(hamiltonian_origin=False)
    print(f"Hamiltonian origin lookup: shape {lookup_ham.shape}")
    print(f"Standard origin lookup: shape {lookup_std.shape}")
    
    print("\n  Hamiltonian origin (frontmost corner):")
    min_h, max_h, min_v, max_v = get_screen_bounds(lookup_ham)
    print(f"    Horizontal: {min_h} to {max_h} (width = {max_h - min_h + 1})")
    print(f"    Vertical: {min_v} to {max_v} (height = {max_v - min_v + 1})")
    
    print("\n  Standard origin (behind plane):")
    min_h, max_h, min_v, max_v = get_screen_bounds(lookup_std)
    print(f"    Horizontal: {min_h} to {max_h} (width = {max_h - min_h + 1})")
    print(f"    Vertical: {min_v} to {max_v} (height = {max_v - min_v + 1})")
    
    # Verify corner diagonal
    print("\nTest 4: Verify corner diagonal")
    z, x, y = 31, 31, 31  # Maximum corner
    h_ham, v_ham = coordinates_to_screen(z, x, y, hamiltonian_origin=True)
    h_std, v_std = coordinates_to_screen(z, x, y, hamiltonian_origin=False)
    
    print(f"  Hamiltonian origin: corner ({z},{x},{y}) -> ({h_ham},{v_ham})")
    print(f"    Diagonal per unit: ({h_ham/31:.2f}, {v_ham/31:.2f})")
    print(f"  Standard origin: corner ({z},{x},{y}) -> ({h_std},{v_std})")
    print(f"    Diagonal per unit: ({h_std/31:.2f}, {v_std/31:.2f})")
    
    # Check for unique screen positions
    print("\nTest 5: Checking for unique screen positions...")
    unique_ham = len(np.unique(lookup_ham, axis=0))
    unique_std = len(np.unique(lookup_std, axis=0))
    print(f"  Hamiltonian origin: {unique_ham:,} / 32,768", end="")
    if unique_ham == 32768:
        print(" ✓ All points visible!")
    else:
        print(f" ✗ {32768 - unique_ham} occluded")
    
    print(f"  Standard origin: {unique_std:,} / 32,768", end="")
    if unique_std == 32768:
        print(" ✓ All points visible!")
    else:
        print(f" ✗ {32768 - unique_std} occluded")
    
    print("\n" + "=" * 70)
