import numpy as np
import matplotlib.pyplot as plt
from cube_32k import (
    create_screen_lookup_table,
    gray_to_coordinates,
    ramp_to_gray
)
from seq_opt import sequency_decompose, print_spectrum_summary
import time

def create_sphere_data(use_r_squared: bool = True, center: tuple = (16, 16, 16)) -> np.ndarray:
    """
    Create sphere data for 32K cube.
    
    For each point in the Hamiltonian path, calculate distance from center.
    Note: center is at fractional position (15.5, 15.5, 15.5) in actual grid,
    but we use (16, 16, 16) as the mathematical center.
    
    Args:
        use_r_squared: If True, use r²; if False, use r
        center: Center coordinates (default is middle of 32x32x32 grid)
    
    Returns:
        Array of 32768 distance values
    """
    data = np.zeros(32768)
    cx, cy, cz = center
    
    for step in range(32768):
        gray = ramp_to_gray(step)
        z, x, y = gray_to_coordinates(gray)
        
        # Calculate distance squared
        r_squared = (z - cz)**2 + (x - cx)**2 + (y - cy)**2
        
        if use_r_squared:
            data[step] = r_squared
        else:
            data[step] = np.sqrt(r_squared)
    
    return data

def analyze_sphere_compression():
    """
    Compare compression ratios for r² vs r.
    """
    print("=" * 70)
    print("Sphere Compression Analysis: r² vs r")
    print("=" * 70)
    
    threshold = 1e-6
    
    # Analyze r²
    print("\n" + "-" * 70)
    print("ANALYSIS 1: r² (sum of quadratics)")
    print("-" * 70)
    
    print("\nGenerating r² data...")
    r_squared_data = create_sphere_data(use_r_squared=True)
    print(f"Data range: {np.min(r_squared_data):.2f} to {np.max(r_squared_data):.2f}")
    
    print("\nPerforming sequency decomposition...")
    start = time.time()
    r_squared_spectrum = sequency_decompose(r_squared_data.copy())
    elapsed = time.time() - start
    print(f"Decomposition time: {elapsed:.4f} seconds")
    
    non_zero_r2 = np.sum(np.abs(r_squared_spectrum) > threshold)
    print(f"\nNon-zero components: {non_zero_r2} / 32,768")
    print(f"Compression ratio: {32768 / non_zero_r2:.1f}x")
    
    print("\nTop 20 spectrum components:")
    print_spectrum_summary(r_squared_spectrum, threshold=threshold, max_display=20)
    
    # Analyze r
    print("\n" + "-" * 70)
    print("ANALYSIS 2: r (square root function)")
    print("-" * 70)
    
    print("\nGenerating r data...")
    r_data = create_sphere_data(use_r_squared=False)
    print(f"Data range: {np.min(r_data):.2f} to {np.max(r_data):.2f}")
    
    print("\nPerforming sequency decomposition...")
    start = time.time()
    r_spectrum = sequency_decompose(r_data.copy())
    elapsed = time.time() - start
    print(f"Decomposition time: {elapsed:.4f} seconds")
    
    non_zero_r = np.sum(np.abs(r_spectrum) > threshold)
    print(f"\nNon-zero components: {non_zero_r} / 32,768")
    print(f"Compression ratio: {32768 / non_zero_r:.1f}x")
    
    print("\nTop 20 spectrum components:")
    print_spectrum_summary(r_spectrum, threshold=threshold, max_display=20)
    
    # Summary comparison
    print("\n" + "=" * 70)
    print("COMPRESSION COMPARISON")
    print("=" * 70)
    print(f"r² non-zero components: {non_zero_r2:6d}  (compression: {32768/non_zero_r2:6.1f}x)")
    print(f"r  non-zero components: {non_zero_r:6d}  (compression: {32768/non_zero_r:6.1f}x)")
    print(f"\nImprovement: {non_zero_r / non_zero_r2:.1f}x fewer components using r²")
    print("=" * 70)
    
    return r_squared_spectrum, r_spectrum, r_squared_data, r_data

def visualize_sphere(use_r_squared: bool = True, save_path: str = None):
    """
    Visualize sphere in 32K cube.
    
    Args:
        use_r_squared: If True, visualize r²; if False, visualize r
        save_path: If provided, save image
    """
    func_name = "r²" if use_r_squared else "r"
    print(f"\n{'=' * 70}")
    print(f"Sphere Visualization: {func_name}")
    print("=" * 70)
    
    # Generate data
    print(f"\nGenerating {func_name} data...")
    data = create_sphere_data(use_r_squared=use_r_squared)
    
    # Create lookup table
    print("Creating screen lookup table...")
    lookup = create_screen_lookup_table(hamiltonian_origin=True)
    
    # Get screen bounds
    from visualize_32k import get_screen_bounds, create_image_from_data
    min_h, max_h, min_v, max_v = get_screen_bounds(lookup)
    
    # Create image
    print("Rendering image...")
    image, extent = create_image_from_data(data, lookup, colormap='hot')
    
    # Create figure
    fig, ax = plt.subplots(figsize=(12, 12), dpi=100)
    
    # Display
    im = ax.imshow(image, extent=extent, origin='lower', 
                   cmap='hot', interpolation='nearest')
    
    cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label(f'Distance {func_name}', fontsize=12)
    
    ax.set_xlabel('Horizontal Screen Coordinate', fontsize=12)
    ax.set_ylabel('Vertical Screen Coordinate', fontsize=12)
    ax.set_title(f'Sphere ({func_name}) in 32K Cube\n' + 
                 'Centered at (16, 16, 16)', fontsize=14, fontweight='bold')
    ax.grid(True, alpha=0.3, linewidth=0.5)
    
    info_text = f'Function: {func_name}\nCenter: (16, 16, 16)\nRange: [{np.min(data):.1f}, {np.max(data):.1f}]'
    ax.text(0.02, 0.98, info_text, transform=ax.transAxes,
            fontsize=10, verticalalignment='top',
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    plt.tight_layout()
    
    if save_path:
        print(f"Saving to {save_path}...")
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        plt.close()
    else:
        plt.show()
    
    return fig, ax

def create_spectrum_comparison_plot(r2_spectrum, r_spectrum, save_path: str = None):
    """
    Create side-by-side comparison of r² vs r spectra.
    
    Args:
        r2_spectrum: Spectrum for r²
        r_spectrum: Spectrum for r
        save_path: Save path for plot
    """
    threshold = 1e-6
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))
    
    # r² spectrum
    indices = np.arange(len(r2_spectrum))
    magnitudes_r2 = np.abs(r2_spectrum)
    non_zero_mask_r2 = magnitudes_r2 > threshold
    
    ax1.semilogy(indices[non_zero_mask_r2], magnitudes_r2[non_zero_mask_r2], 
                'bo', markersize=3, label='Non-zero components')
    ax1.set_xlabel('Sequency Index', fontsize=12)
    ax1.set_ylabel('|Amplitude| (log scale)', fontsize=12)
    ax1.set_title(f'r² Spectrum\n({np.sum(non_zero_mask_r2)} non-zero components)', 
                 fontsize=14, fontweight='bold')
    ax1.grid(True, alpha=0.3, which='both')
    ax1.legend()
    
    # r spectrum
    magnitudes_r = np.abs(r_spectrum)
    non_zero_mask_r = magnitudes_r > threshold
    
    ax2.semilogy(indices[non_zero_mask_r], magnitudes_r[non_zero_mask_r], 
                'ro', markersize=3, label='Non-zero components')
    ax2.set_xlabel('Sequency Index', fontsize=12)
    ax2.set_ylabel('|Amplitude| (log scale)', fontsize=12)
    ax2.set_title(f'r Spectrum\n({np.sum(non_zero_mask_r)} non-zero components)', 
                 fontsize=14, fontweight='bold')
    ax2.grid(True, alpha=0.3, which='both')
    ax2.legend()
    
    plt.tight_layout()
    
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"Comparison plot saved to {save_path}")
        plt.close()
    else:
        plt.show()

if __name__ == "__main__":
    # Run compression analysis
    r2_spec, r_spec, r2_data, r_data = analyze_sphere_compression()
    
    # Create visualizations
    print("\n" + "=" * 70)
    print("Creating Visualizations")
    print("=" * 70)
    
    visualize_sphere(use_r_squared=True, 
                    save_path='/mnt/user-data/outputs/sphere_r_squared.png')
    
    visualize_sphere(use_r_squared=False, 
                    save_path='/mnt/user-data/outputs/sphere_r.png')
    
    create_spectrum_comparison_plot(r2_spec, r_spec,
                                   save_path='/mnt/user-data/outputs/sphere_spectrum_comparison.png')
    
    print("\n" + "=" * 70)
    print("All sphere visualizations complete!")
    print("=" * 70)
    print("\nOutput files:")
    print("  - sphere_r_squared.png")
    print("  - sphere_r.png")
    print("  - sphere_spectrum_comparison.png")
