# Quick Start Guide

## Installation

```bash
# Clone repository
git clone https://github.com/YourUsername/21st-century-physics.git
cd 21st-century-physics

# Install dependencies
pip install -r requirements.txt
```

## 30-Second Test

```bash
# Run basic examples
cd examples
python basic_usage.py
```

## 5-Minute Demo

```bash
# Run complete 32K demo
cd examples
python 32k_demo.py
```

This generates:
- Unit ramp in 32K cube
- Sequency spectrum analysis
- Polynomial visualizations
- Sphere compression comparison
- Walsh function basis images
- Animated Hamiltonian path

## Your First Analysis

```python
from src.seq_opt import analyze_data

# Your data (any list of numbers)
my_data = [1.0, 2.5, 3.2, 4.1, 2.8, 1.5, 3.0, 4.5]

# Analyze
result = analyze_data(my_data)

# View results
print(f"Spectrum: {result['spectrum']}")
print(f"Reconstruction error: {result['error']}")
```

## What to Try

### 1. Different Data Types
```python
# From file
result = analyze_data('mydata.txt')

# NumPy array
import numpy as np
data = np.random.randn(1024)
result = analyze_data(data)
```

### 2. Visualize 32K Cube
```python
from src.visualize_32k import visualize_32k_ramp
visualize_32k_ramp(save_path='my_ramp.png')
```

### 3. See Walsh Functions
```python
from src.sequency_visualizer import visualize_single_sequency

# Visualize W7 (7 zero crossings)
visualize_single_sequency(7, save_path='W7.png')
```

### 4. Compare Compression
```python
from src.sphere_analysis import analyze_sphere_compression
analyze_sphere_compression()
```

## Understanding Results

### Spectrum
- Index 0 (W0): DC component (average value)
- Index 1 (W1): Lowest frequency (1 zero crossing)
- Index 3 (W3): 3 zero crossings
- Higher indices: more zero crossings

### Compression Ratio
```
Compression = Total Samples / Non-Zero Components

Examples:
- Unit ramp (32K): 2048x compression
- Quadratic (32K): ~200x compression  
- Sphere r² (32K): 712x compression
- Random noise: ~1x (no compression)
```

### When Sequency Works Best
✓ Polynomial functions
✓ Piecewise constant functions
✓ Step functions
✓ Functions with structure

✗ Random noise
✗ Non-polynomial transcendentals (sin, exp, √x)
✗ Highly irregular data

## Next Steps

1. **Explore examples/** - See more use cases
2. **Read docs/** - Understand the mathematics
3. **Modify src/** - Experiment with the code
4. **Share results** - Show us what you find!

## Common Issues

**"Module not found"**
- Make sure you're running from the examples/ directory
- Or add src/ to your Python path

**"Array length must be power of 2"**
- Pad your data to 256, 512, 1024, etc.
- The analyze_data() function does this automatically

**"Out of memory"**
- 32K (32,768 points) needs ~2MB RAM
- Larger sizes scale linearly

## Getting Help

- Check examples/ for similar use cases
- Read README.md for detailed documentation
- Open an issue on GitHub
- Contact [your email]

## Performance Tips

**Current Python implementation:**
- 32K decomposition: ~0.12 seconds
- Good for exploration and visualization

**For production use:**
- Use Numba JIT: Add @jit decorator (~10x faster)
- Compile to C: Use Cython (~50x faster)
- Write in assembly: Ultimate performance (~100x+ faster)

The algorithm is naturally parallel - perfect for GPUs!
