# Technical Overview

## Sequency Decomposition Algorithm

### Core Concept

Sequency decomposition is a transform similar to the Fourier transform, but based on **sequency** (number of zero crossings) rather than frequency. It uses the Walsh-Hadamard basis functions which consist of +1 and -1 values only.

### Mathematical Foundation

#### Transform Definition
For an input signal x[n] of length N = 2^k:

1. **Bit-reverse** the input array
2. **Apply recursive sum/difference operations:**
   - Stage 1 (2D modules): Process pairs
   - Stages 2 to k (4D modules): Process groups of 4
3. **Normalize** by 1/√N

#### Sum/Difference Pattern

**2D Module (Stage 1):**
```
a' = a + b
b' = a - b
```

**4D Module (Subsequent stages):**
```
a' = a + b
b' = a - b  
c' = c - d
d' = c + d
```

Note the "swapped" subtraction in the second pair (c' = c - d, d' = c + d) - this is what makes the transform recursive and auto-inverse.

### Auto-Inverse Property

**Key Feature:** The sequency transform is its own inverse!

```
Decompose: x → X
Reconstruct: X → x
```

Both operations use the exact same algorithm. This is analogous to how the Hadamard matrix is its own inverse (up to scaling).

### Why It Works

The Walsh functions form a **complete orthonormal basis**:
- Each function is orthogonal to all others
- Inner product of function with itself = N
- Spans the entire N-dimensional space

### Complexity

**Time complexity:** O(N log N)
- Same as FFT
- Each stage processes all N elements
- log₂(N) stages total

**Space complexity:** O(N)
- In-place algorithm possible
- Only need working array

## 32K Cube Visualization

### Gray Code Bit Interleaving

The 32K cube uses a sophisticated mapping that creates a **Hamiltonian path** through the 32×32×32 grid - a path that visits every point exactly once.

#### Bit Mapping

For a 15-bit position number with bits ABCDEFGHIJKLMNO:
- **z-coordinate** (5 bits): ADGJM
- **x-coordinate** (5 bits): BEHKN
- **y-coordinate** (5 bits): CFILO

This "dealing" of bits ensures neighboring points in the linear sequence remain relatively close in 3D space.

#### Why Gray Code?

Gray code has the property that adjacent numbers differ by exactly one bit. Combined with bit-interleaving:
- Smooth path through space
- Preserves locality
- Minimizes "jumps" in the folded path

### Screen Projection

**Unit vectors:**
```
z: ( 6,  2)
x: ( 0, -7)
y: (-5,  2)
```

**Projection formula:**
```
horizontal = 6z - 5y
vertical = 2(z + y) - 7x
```

**Key property:** All 32,768 points map to unique screen positions with NO OCCLUSION.

#### Why These Particular Vectors?

The vectors are chosen to be:
1. **Relatively prime** - ensures no overlap
2. **Appropriately scaled** - spreads points across screen
3. **Balanced** - roughly symmetric distribution

### Geometric Properties

**Corner diagonal:**
- Direction: (1, -3) 
- One unit in each coordinate → diagonal moves (1, -3) on screen
- This is (1, 1, 1) in cube coords → (6-5+0, 2+2-7) = (1, -3)

**The 2:(-1) plane:**
- Plane defined by unit vector tips
- Intersects corner diagonal at 1/√3 from origin
- Creates natural 2:(-1) charge-like splitting
- Front corner: +2/√3 from plane
- Back corner: -1/√3 from plane

## Compression Analysis

### Why Polynomials Compress Well

A polynomial of degree d can be written as:
```
p(x) = a₀ + a₁x + a₂x² + ... + aₐx^d
```

In sequency space, powers of x have sparse representations:
- x⁰ (constant): 1 component (W0)
- x¹ (linear): log₂(N) components (W0, W1, W3, W7, ...)
- x² (quadratic): More components, but still O(log N)

**Result:** Polynomial of degree d needs O(d · log N) components

### Why Roots Don't Compress

Functions like √x cannot be written as finite polynomials. They require infinite series:
```
√x = √a · (1 + (x-a)/2a - (x-a)²/8a² + ...)
```

In sequency space, this infinite series translates to needing essentially all components.

### Sphere Example

**Sphere using r²:**
```
r² = (x-16)² + (y-16)² + (z-16)²
   = x² + y² + z² - 32x - 32y - 32z + 768
```

This is a **sum of quadratic terms** → polynomial → sparse!

**Result:** 46 components out of 32,768 (712x compression)

**Sphere using r:**
```
r = √(r²)
```

Square root function → non-polynomial → dense spectrum

**Result:** All 32,768 components needed (1x compression)

## Applications

### Digital Signal Processing

**Fundamental functions:**
- Unit ramp: r[n] = n
- Unit step: δ[n] = 1 for n ≥ 0, else 0
- Unit impulse: δ[n] = 1 for n = 0, else 0

These are related by differentiation/integration. In sequency space, the unit ramp uses only 2^k - 1 sequencies (16 components for 32K samples).

### Electromagnetic Fields

**Particular solutions** for electromagnetic fields have shapes determined by source geometry. If we know:
- Source geometry → sparse sequency representation
- Field equation coefficients → transfer function

Then:
- Output field = Transfer function × Source spectrum
- Prediction is trivial in sequency space!

### Pattern Recognition

**Hypothesis:** Sequency decomposition may be fundamental to intelligence.

**Evidence:**
1. **Efficient representation** - sparse for structured data
2. **Hierarchical structure** - natural from recursive algorithm  
3. **Hardware-friendly** - simple bit operations
4. **Fast processing** - O(N log N) operations

The brain might use something analogous to sequency decomposition for efficient pattern storage and recognition.

## Performance Optimization

### Current Python Implementation
- Pure NumPy operations
- ~0.12 seconds for 32K decomposition
- Good for exploration and visualization

### Optimization Paths

**1. Numba JIT Compilation**
```python
from numba import jit

@jit(nopython=True)
def sequency_decompose(data):
    # ... algorithm ...
```
Expected speedup: **~10x**

**2. Cython**
```cython
cdef void sequency_decompose(double* data, int n):
    # ... C-level code ...
```
Expected speedup: **~50x**

**3. C Extension**
Pure C with Python wrapper
Expected speedup: **~100x**

**4. Assembly + SIMD**
Hand-optimized assembly with AVX-512
Expected speedup: **~200x+**

### Parallelization

The algorithm is **naturally parallel** at each stage:
- Stage operations are independent across groups
- Perfect for SIMD (AVX, NEON)
- GPU-friendly (each thread handles one group)

**GPU implementation** could achieve **1000x+ speedup** for large N.

## Mathematical Connections

### Relationship to Other Transforms

**Walsh-Hadamard Transform:**
Sequency decomposition is a reordered Walsh-Hadamard transform where basis functions are ordered by sequency (zero crossings) rather than natural binary order.

**Fourier Transform:**
- Fourier: basis = complex exponentials
- Sequency: basis = square waves
- Both are complete orthonormal bases
- Both have fast O(N log N) algorithms

**Wavelet Transform:**
- Wavelets: localized in time and frequency
- Sequency: localized in sequency
- Both create hierarchical representations

### Group Theory

The transform has connections to:
- **Dihedral groups** - reflections and rotations
- **Permutation groups** - bit reversals
- **Abelian groups** - component-wise operations

The 4D symmetry in the cube relates to the **Klein four-group** (Z₂ × Z₂).

## Open Questions

1. **Optimal basis?** Is sequency the "best" discrete basis for physical problems?

2. **Quantum connection?** Does the 2:(-1) charge splitting have deeper significance?

3. **Neural implementation?** Could biological neurons implement sequency-like transforms?

4. **Field applications?** What other physics problems have sparse sequency representations?

5. **Optimization limits?** How fast can the algorithm theoretically go?

## References

- Graphics.pdf - Original 32K cube documentation
- Repository examples/ - Practical demonstrations
- Source code comments - Implementation details
