"""
Basic Usage Examples for Sequency Decomposition

This file demonstrates the fundamental operations of the sequency
decomposition system.
"""

import sys
sys.path.append('../src')

import numpy as np
from seq_opt import (
    sequency_decompose, 
    sequency_reconstruct,
    analyze_data,
    print_spectrum_summary
)

def example_1_simple_list():
    """Example 1: Decompose a simple list of numbers."""
    print("=" * 70)
    print("Example 1: Simple List Decomposition")
    print("=" * 70)
    
    # Your data
    my_data = [1.0, 2.5, 3.2, 4.1, 2.8, 1.5, 3.0, 4.5]
    
    # Analyze
    result = analyze_data(my_data)
    
    # Display results
    print(f"\nOriginal data: {my_data}")
    print(f"Reconstruction error: {result['error']:.2e}")
    print("\nSpectrum:")
    print_spectrum_summary(result['spectrum'], max_display=8)

def example_2_unit_ramp():
    """Example 2: Unit ramp - fundamental DSP function."""
    print("\n" + "=" * 70)
    print("Example 2: Unit Ramp (Fundamental DSP Function)")
    print("=" * 70)
    
    # Create unit ramp
    n = 256
    ramp = np.arange(n, dtype=float)
    
    # Decompose
    result = analyze_data(ramp)
    
    print(f"\nUnit ramp: 0, 1, 2, ..., {n-1}")
    print(f"Reconstruction error: {result['error']:.2e}")
    print("\nSpectrum (only non-zero components):")
    print_spectrum_summary(result['spectrum'], threshold=1e-10, max_display=15)
    
    # Count non-zero components
    non_zero = np.sum(np.abs(result['spectrum']) > 1e-10)
    print(f"\nCompression: {non_zero} components / {n} samples = {n/non_zero:.1f}x")

def example_3_polynomial():
    """Example 3: Polynomial functions compress well."""
    print("\n" + "=" * 70)
    print("Example 3: Polynomial Compression")
    print("=" * 70)
    
    n = 1024
    t = np.arange(n) / (n-1)  # Normalize to [0, 1]
    
    # Test different polynomials
    for degree in [1, 2, 3]:
        data = t ** degree
        spectrum = sequency_decompose(data.copy())
        
        non_zero = np.sum(np.abs(spectrum) > 1e-10)
        print(f"\nt^{degree}: {non_zero} non-zero components (compression: {n/non_zero:.1f}x)")

def example_4_reconstruction():
    """Example 4: Verify perfect reconstruction."""
    print("\n" + "=" * 70)
    print("Example 4: Perfect Reconstruction")
    print("=" * 70)
    
    # Random data
    np.random.seed(42)
    data = np.random.randn(512)
    
    # Decompose
    spectrum = sequency_decompose(data.copy())
    
    # Reconstruct
    reconstructed = sequency_reconstruct(spectrum.copy())
    
    # Compare
    error = np.max(np.abs(reconstructed - data))
    
    print(f"\nOriginal data: {len(data)} random samples")
    print(f"Max reconstruction error: {error:.2e}")
    print(f"Perfect reconstruction: {error < 1e-10}")

def example_5_compare_vs_sqrt():
    """Example 5: Why polynomials compress better than roots."""
    print("\n" + "=" * 70)
    print("Example 5: Polynomial vs Square Root Compression")
    print("=" * 70)
    
    n = 1024
    t = np.arange(n, dtype=float)
    
    # Quadratic
    data_quad = t ** 2
    spec_quad = sequency_decompose(data_quad.copy())
    nz_quad = np.sum(np.abs(spec_quad) > 1e-6)
    
    # Square root
    data_sqrt = np.sqrt(t)
    spec_sqrt = sequency_decompose(data_sqrt.copy())
    nz_sqrt = np.sum(np.abs(spec_sqrt) > 1e-6)
    
    print(f"\nt² (polynomial):")
    print(f"  Non-zero components: {nz_quad}")
    print(f"  Compression: {n/nz_quad:.1f}x")
    
    print(f"\n√t (square root):")
    print(f"  Non-zero components: {nz_sqrt}")
    print(f"  Compression: {n/nz_sqrt:.1f}x")
    
    print(f"\nRatio: {nz_sqrt/nz_quad:.1f}x more components needed for √t")

def example_6_custom_data():
    """Example 6: Template for your own data."""
    print("\n" + "=" * 70)
    print("Example 6: Your Data Here")
    print("=" * 70)
    
    # Load your data here
    # Option 1: From file
    # data = np.loadtxt('mydata.txt')
    
    # Option 2: From list
    # data = [1.2, 3.4, 5.6, ...]
    
    # Option 3: Generate function
    n = 256
    x = np.linspace(0, 2*np.pi, n)
    data = np.sin(x) + 0.5 * np.cos(3*x)
    
    # Analyze
    result = analyze_data(data, show_reconstruction=True)
    
    print(f"\nData samples: {len(data)}")
    print(f"Reconstruction error: {result['error']:.2e}")
    print("\nTop spectrum components:")
    print_spectrum_summary(result['spectrum'], max_display=10)

if __name__ == "__main__":
    example_1_simple_list()
    example_2_unit_ramp()
    example_3_polynomial()
    example_4_reconstruction()
    example_5_compare_vs_sqrt()
    example_6_custom_data()
    
    print("\n" + "=" * 70)
    print("All examples complete!")
    print("=" * 70)
    print("\nKey Takeaways:")
    print("1. Sequency transform is auto-inverse (decompose = reconstruct)")
    print("2. Polynomial functions compress extremely well")
    print("3. Non-polynomial functions (like √x) compress poorly")
    print("4. Reconstruction is numerically perfect (errors at machine precision)")
    print("5. Unit ramp uses only 2^n - 1 sequencies (exponential compression)")
