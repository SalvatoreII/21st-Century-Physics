"""
32K Cube Demonstration

Complete demonstration of the 32K cube visualization system including:
- Hamiltonian path through 32³ grid
- Unit ramp visualization
- Sequency basis functions
- Sphere compression analysis
- Animated path visualization
"""

import sys
sys.path.append('../src')

import numpy as np
from cube_32k import (
    create_screen_lookup_table,
    ramp_to_screen,
    coordinates_to_screen
)
from visualize_32k import (
    visualize_32k_ramp,
    analyze_and_visualize_ramp,
    create_polynomial_visualization
)
from sphere_analysis import (
    analyze_sphere_compression,
    visualize_sphere
)
from sequency_visualizer import (
    visualize_primary_rademacher_functions,
    visualize_single_sequency,
    create_hamiltonian_path_animation
)

def demo_coordinate_system():
    """Demonstrate the coordinate system."""
    print("=" * 70)
    print("32K Cube Coordinate System Demo")
    print("=" * 70)
    
    print("\nKey properties:")
    print("- 32 × 32 × 32 grid = 32,768 points")
    print("- Gray code bit-interleaving for Hamiltonian path")
    print("- All points visible simultaneously (no occlusion)")
    print("- Screen projection: (6,2), (0,-7), (-5,2)")
    print("- Corner diagonal: (1, -3) or (-1, 3) depending on origin")
    
    # Test a few points
    print("\nSample coordinate conversions:")
    for step in [0, 1, 100, 32767]:
        h, v = ramp_to_screen(step, hamiltonian_origin=True)
        print(f"  Step {step:5d} → screen ({h:4d}, {v:4d})")
    
    # Create lookup table
    print("\nCreating lookup table for all 32K points...")
    lookup = create_screen_lookup_table(hamiltonian_origin=True)
    print(f"Lookup table shape: {lookup.shape}")
    print("✓ Coordinate system ready")

def demo_unit_ramp():
    """Demonstrate unit ramp visualization."""
    print("\n" + "=" * 70)
    print("Unit Ramp Demonstration")
    print("=" * 70)
    
    print("\nThe unit ramp is fundamental to DSP:")
    print("- Derivative → unit step function")
    print("- Second derivative → unit impulse")
    print("- Basis for countless time/space functions")
    
    print("\nGenerating 32K unit ramp visualization...")
    visualize_32k_ramp(
        save_path='../outputs/demo_32k_ramp.png',
        show_plot=False
    )
    print("✓ Saved to outputs/demo_32k_ramp.png")
    
    print("\nPerforming sequency analysis...")
    spectrum = analyze_and_visualize_ramp(
        save_spectrum_path='../outputs/demo_ramp_spectrum.png'
    )
    print("✓ Saved to outputs/demo_ramp_spectrum.png")

def demo_polynomials():
    """Demonstrate polynomial visualization."""
    print("\n" + "=" * 70)
    print("Polynomial Functions Demonstration")
    print("=" * 70)
    
    print("\nPolynomials compress extremely well in sequency space")
    print("because they are built from sums of powers.")
    
    for degree in [2, 3, 4]:
        print(f"\nGenerating t^{degree}...")
        create_polynomial_visualization(
            degree=degree,
            save_path=f'../outputs/demo_polynomial_t{degree}.png'
        )
        print(f"✓ Saved to outputs/demo_polynomial_t{degree}.png")

def demo_sphere():
    """Demonstrate sphere analysis."""
    print("\n" + "=" * 70)
    print("Sphere Compression Demonstration")
    print("=" * 70)
    
    print("\nComparing r² vs r for sphere representation:")
    print("- r² is polynomial → sparse spectrum")
    print("- r is square root → dense spectrum")
    
    r2_spec, r_spec, r2_data, r_data = analyze_sphere_compression()
    
    print("\n✓ Sphere analysis complete")
    
    print("\nGenerating visualizations...")
    visualize_sphere(use_r_squared=True, 
                    save_path='../outputs/demo_sphere_r2.png')
    visualize_sphere(use_r_squared=False,
                    save_path='../outputs/demo_sphere_r.png')
    print("✓ Sphere visualizations saved")

def demo_basis_functions():
    """Demonstrate sequency basis functions."""
    print("\n" + "=" * 70)
    print("Sequency Basis Functions (Walsh Functions)")
    print("=" * 70)
    
    print("\nVisualizing primary Rademacher functions:")
    print("W0, W1, W3, W7, W15, W31, W63, W127, W255, W511, W1023")
    print("These are the 2^n - 1 sequencies")
    
    visualize_primary_rademacher_functions(save_dir='../outputs')
    print("✓ Primary Rademacher functions saved")
    
    print("\nThese images show how each sequency component")
    print("manifests spatially in the folded Hamiltonian path.")

def demo_animation():
    """Create sample animation."""
    print("\n" + "=" * 70)
    print("Hamiltonian Path Animation")
    print("=" * 70)
    
    print("\nCreating 10-second animation of W1 flowing through path...")
    print("(Full 60-second animations can be created with duration_seconds=60)")
    
    create_hamiltonian_path_animation(
        sequency_index=1,
        save_path='../outputs/demo_W1_animation.gif',
        duration_seconds=10.0,
        fps=10
    )
    print("✓ Animation saved to outputs/demo_W1_animation.gif")

def run_full_demo():
    """Run complete demonstration suite."""
    print("\n" + "=" * 70)
    print("COMPLETE 32K CUBE DEMONSTRATION")
    print("=" * 70)
    print("\nThis will generate all visualization examples.")
    print("Output directory: outputs/")
    print("\nStarting...\n")
    
    # Run all demos
    demo_coordinate_system()
    demo_unit_ramp()
    demo_polynomials()
    demo_sphere()
    demo_basis_functions()
    demo_animation()
    
    print("\n" + "=" * 70)
    print("DEMONSTRATION COMPLETE!")
    print("=" * 70)
    print("\nGenerated files in outputs/:")
    print("  - demo_32k_ramp.png")
    print("  - demo_ramp_spectrum.png")
    print("  - demo_polynomial_t2.png, t3.png, t4.png")
    print("  - demo_sphere_r2.png, demo_sphere_r.png")
    print("  - sequency_W0000.png through sequency_W1023.png")
    print("  - demo_W1_animation.gif")
    print("\nKey findings:")
    print("  • Unit ramp: 2048x compression (16/32768 components)")
    print("  • Sphere r²: 712x compression (46/32768 components)")
    print("  • Sphere r: 1x compression (all 32768 components needed)")
    print("  • All 32,768 points visible in projection (no occlusion)")
    print("\n" + "=" * 70)

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1:
        demo_name = sys.argv[1]
        demos = {
            'coords': demo_coordinate_system,
            'ramp': demo_unit_ramp,
            'poly': demo_polynomials,
            'sphere': demo_sphere,
            'basis': demo_basis_functions,
            'anim': demo_animation,
            'all': run_full_demo
        }
        
        if demo_name in demos:
            demos[demo_name]()
        else:
            print(f"Unknown demo: {demo_name}")
            print(f"Available: {', '.join(demos.keys())}")
    else:
        # Run full demo by default
        run_full_demo()
