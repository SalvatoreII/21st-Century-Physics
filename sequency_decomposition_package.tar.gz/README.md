# Sequency Decomposition - Python Implementation

Python implementation of sequency decomposition algorithm with 32K cube visualization system.

## Overview

This repository provides:
- Fast sequency decomposition algorithm (Walsh-Hadamard transform variant)
- 32K cube visualization using Gray code bit-interleaving
- Hamiltonian path through 3D grid
- Basis function visualization
- Applications to geometric shapes and field analysis

## Quick Start

### Basic Sequency Decomposition

```python
from src.seq_opt import sequency_decompose, analyze_data

# Decompose data
data = [1.0, 2.5, 3.2, 4.1, 2.8, 1.5, 3.0, 4.5]
result = analyze_data(data)

# Access results
spectrum = result['spectrum']
reconstructed = result['reconstructed']
error = result['error']
```

### 32K Cube Visualization

```python
from src.visualize_32k import visualize_32k_ramp

# Visualize unit ramp in 32K cube
visualize_32k_ramp(save_path='ramp.png')
```

### Sequency Basis Functions

```python
from src.sequency_visualizer import visualize_single_sequency

# Visualize Walsh function W7
visualize_single_sequency(7, save_path='W7.png')
```

## Key Features

### Sequency Decomposition (`seq_opt.py`)
- Auto-inverse transform (decompose = reconstruct)
- O(n log n) complexity
- Deferred normalization for efficiency
- Support for arbitrary power-of-2 lengths

### 32K Cube System (`cube_32k.py`)
- Gray code bit-interleaving for Hamiltonian path
- All 32,768 points visible simultaneously
- No occlusion in projection
- Reversible coordinate transformations

### Performance
- **32K decomposition**: ~0.12 seconds (Python)
- **Compression examples**:
  - Unit ramp: 2048x (16/32768 components)
  - Sphere (r²): 712x (46/32768 components)
  - Sphere (r): 1x (no compression - all components needed)

## Mathematics

### Sequency Transform
The sequency transform uses sum/difference operations recursively:
- Stage 1 (2D modules): pairs at maximum spacing
- Stages 2-n (4D modules): groups of 4, spacing halving each stage
- Final normalization: 1/√n where n = number of samples

### Why r² vs r for Spheres?
- r² = (x-c)² + (y-c)² + (z-c)² is polynomial → sparse spectrum
- r = √(r²) involves square root → dense spectrum (no compression)
- **Result**: 712x fewer components using r² instead of r

### Gray Code Bit Interleaving
15-bit Gray code ABCDEFGHIJKLMNO dealt into three 5-bit coordinates:
- z: ADGJM (bits 14, 11, 8, 5, 2)
- x: BEHKN (bits 13, 10, 7, 4, 1)  
- y: CFILO (bits 12, 9, 6, 3, 0)

Screen projection uses unit vectors (6,2), (0,-7), (-5,2) for no occlusion.

## Applications

### Digital Signal Processing
- Unit ramp fundamental function
- Derivative → unit step
- Second derivative → unit impulse

### Electromagnetic Fields
Since particular solutions copy source field shapes, sequency decomposition provides:
- Trivial prediction of field shapes from material geometry
- Compact representation of volumetric fields
- Efficient field calculations

### Pattern Recognition
Sequency decomposition may be fundamental to intelligence through:
- Efficient pattern recognition via sparse representation
- Natural hierarchical structure from recursive algorithm
- Hardware-friendly bit manipulation

## File Structure

```
src/
  seq_opt.py              - Core sequency decomposition
  cube_32k.py             - 32K cube coordinate system
  visualize_32k.py        - Ramp and polynomial visualization
  sphere_analysis.py      - Sphere compression analysis
  sequency_visualizer.py  - Basis function visualization

examples/
  basic_usage.py          - Simple examples
  32k_demo.py             - Full 32K demonstrations

docs/
  Graphics.pdf            - Original 32K cube documentation
  
outputs/
  (Generated visualizations)
```

## Requirements

```
numpy
matplotlib
```

## Installation

```bash
git clone https://github.com/YourUsername/21st-century-physics.git
cd 21st-century-physics
pip install numpy matplotlib
```

## Examples

See `examples/` directory for:
- Basic sequency decomposition
- 32K cube visualization
- Sphere analysis
- Basis function generation
- Hamiltonian path animation

## Performance Notes

Current Python implementation is educational. For production use:
- Numba JIT compilation: ~10x speedup
- C extension: ~50x speedup  
- Assembly with SIMD: ~100x+ speedup

The algorithm is naturally parallel and hardware-friendly.

## Contributing

This is open-source research. Contributions welcome:
- Optimizations (Numba, Cython, C)
- Additional geometric shapes library
- Field theory applications
- Visualization improvements

## License

Open source - see LICENSE file

## Citation

If you use this work, please cite:
[Your citation information]

## Contact

[Your contact information]

## Acknowledgments

This work represents many years of development in sequency analysis, alternative physics frameworks, and visualization techniques.
